import { createClient } from '@supabase/supabase-js';
import './style.css';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = url && key && !url.includes('SEU-PROJETO')
  ? createClient(url, key)
  : null;

const app = document.querySelector('#app');
let currentUser = null;
let profile = null;
let page = 'home';

const esc = (s='') => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => Number(n || 0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const teacher = () => profile?.role === 'teacher';

function shell(content) {
  app.innerHTML = `
    <div class="layout">
      <aside class="sidebar">
        <div class="brand"><div class="mark">🥋</div><div><b>CT GENILSON<br>CACHORRÃO</b><small>GESTÃO DA ACADEMIA</small></div></div>
        <div class="userbox"><b>${esc(profile?.full_name || currentUser?.email || 'Usuário')}</b><small>${teacher()?'Professor':'Aluno'}</small></div>
        <nav>${navItem('home','⌂','Início')}${teacher()?navItem('students','♟','Alunos'):''}${navItem('attendance','▣','Presenças')}${navItem('finance','▤','Mensalidades')}${navItem('graduations','⚑','Graduações')}<button id="logout" class="navitem">↪ Sair</button></nav>
        <small class="foot">Disciplina • Respeito • Evolução</small>
      </aside>
      <main><header><div><small class="eyebrow">CT GENILSON CACHORRÃO</small><h1>${pageTitle()}</h1></div><span class="avatar">${esc((profile?.full_name||'GC').split(' ').map(x=>x[0]).slice(0,2).join(''))}</span></header>${content}</main>
      <nav class="bottomnav">${navItem('home','⌂','Início')}${teacher()?navItem('students','♟','Alunos'):''}${navItem('attendance','▣','Presenças')}${navItem('finance','▤','Financeiro')}</nav>
    </div>`;
  app.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));
  document.querySelector('#logout')?.addEventListener('click',async()=>{await supabase.auth.signOut();currentUser=null;profile=null;renderAuth()});
}
function navItem(id,icon,label){return `<button class="navitem ${page===id?'active':''}" data-page="${id}"><span>${icon}</span>${label}</button>`}
function pageTitle(){return ({home:'Painel',students:'Alunos',attendance:'Presenças',finance:'Mensalidades',graduations:'Graduações'})[page]||'Painel'}
function renderAuth(message='') {
  app.innerHTML = `<div class="authwrap"><section class="authcard"><div class="logo-large">🥋</div><small class="eyebrow">DISCIPLINA • RESPEITO • EVOLUÇÃO</small><h1>CT GENILSON<br><span>CACHORRÃO</span></h1><p class="muted">A gestão da academia na palma da mão.</p><form id="login"><label>E-mail<input id="email" type="email" required placeholder="voce@email.com" autocomplete="email"></label><label>Senha<input id="password" type="password" required minlength="6" placeholder="Sua senha" autocomplete="current-password"></label><button class="primary" type="submit">Entrar</button><p class="notice" id="authmsg">${esc(message || (!supabase?'Configure as credenciais do Supabase para ativar o login real.':''))}</p></form><small class="muted">Acesso individual para professor e alunos.</small></section></div>`;
  document.querySelector('#login').addEventListener('submit', async e=>{
    e.preventDefault();
    if(!supabase){document.querySelector('#authmsg').textContent='O projeto ainda precisa ser conectado ao Supabase. Veja o README e o arquivo .env.example.';return;}
    const {data,error}=await supabase.auth.signInWithPassword({email:document.querySelector('#email').value,password:document.querySelector('#password').value});
    if(error){document.querySelector('#authmsg').textContent=error.message;return;}
    await loadUser(data.user);
  });
}
async function loadUser(user) {
  currentUser=user;
  const {data,error}=await supabase.from('profiles').select('*').eq('id',user.id).maybeSingle();
  if(error || !data){renderAuth('Conta autenticada, mas o perfil não foi encontrado. Peça ao administrador para configurar seu perfil.');return;}
  profile=data;page='home';await renderPage();
}
async function go(p){page=p;await renderPage()}
async function renderPage(){
  if(!supabase||!currentUser||!profile){renderAuth();return;}
  let content='';
  if(page==='home'){
    const {data:att=[]}=await supabase.from('attendance').select('id,checked_in_at,student_id').order('checked_in_at',{ascending:false}).limit(10);
    const {data:fees=[]}=await supabase.from('memberships').select('id,amount,paid_at,due_date');
    const pending=fees.filter(f=>!f.paid_at).length;
    content=`<section class="hero"><small class="eyebrow">OSS! 🥋</small><h2>Olá, ${esc(profile.full_name.split(' ')[0])}!</h2><p>${teacher()?'Aqui está o resumo da academia.':'Acompanhe sua evolução e suas presenças.'}</p></section>
    <div class="stats"><article><small>${teacher()?'Presenças recentes':'Minhas presenças carregadas'}</small><b>${att.length}</b></article><article><small>${teacher()?'Mensalidades pendentes':'Mensalidades na sua conta'}</small><b>${teacher()?pending:fees.length}</b></article><article><small>Minha faixa</small><b class="belt">${esc(profile.belt||'Branca')}</b></article></div>
    <section class="panel"><h3>Ações rápidas</h3><div class="actions"><button class="tile" data-page="attendance">▣<b>Registrar presença</b><small>Fazer check-in</small></button><button class="tile" data-page="finance">▤<b>Mensalidades</b><small>Ver situação</small></button><button class="tile" data-page="graduations">⚑<b>Graduações</b><small>Histórico de faixa</small></button>${teacher()?'<button class="tile" data-page="students">♟<b>Alunos</b><small>Gerenciar cadastros</small></button>':''}</div></section>`;
  } else if(page==='students' && teacher()){
    const {data:people=[],error}=await supabase.from('profiles').select('id,full_name,belt,degree,role').eq('role','student').order('full_name');
    content=`<section class="panel"><h3>Alunos cadastrados</h3><p class="muted">O cadastro de autenticação e o perfil precisam ser criados com segurança no Supabase.</p>${error?`<p class="notice">${esc(error.message)}</p>`:people.length?people.map(p=>`<div class="item"><span class="avatar">${esc(p.full_name.slice(0,1))}</span><div class="grow"><b>${esc(p.full_name)}</b><small>${esc(p.belt)} • ${esc(p.degree||'')}</small></div></div>`).join(''):'<p class="muted">Ainda não há alunos cadastrados.</p>'}</section>`;
  } else if(page==='attendance'){
    content=`<section class="panel centered"><div class="bigicon">▣</div><h2>Registrar presença</h2><p class="muted">Confirme que você está na academia antes de registrar.</p><button class="primary" id="checkin">Confirmar meu check-in</button><p id="result" class="muted"></p></section><section class="panel"><h3>Histórico recente</h3><div id="attlist" class="muted">Carregando...</div></section>`;
  } else if(page==='finance'){
    const {data:fees=[],error}=await supabase.from('memberships').select('*').order('due_date',{ascending:false});
    content=`<section class="panel"><h3>${teacher()?'Mensalidades da academia':'Minhas mensalidades'}</h3>${error?`<p class="notice">${esc(error.message)}</p>`:fees.length?fees.map(f=>`<div class="item"><div class="grow"><b>${money(f.amount)}</b><small>Vencimento: ${esc(f.due_date)}</small></div><span class="status ${f.paid_at?'paid':'pending'}">${f.paid_at?'Paga':'Pendente'}</span></div>`).join(''):'<p class="muted">Nenhuma mensalidade cadastrada.</p>'}</section>`;
  } else if(page==='graduations'){
    const {data:grads=[],error}=await supabase.from('graduations').select('*').order('awarded_at',{ascending:false});
    content=`<section class="panel"><h3>Histórico de graduações</h3>${error?`<p class="notice">${esc(error.message)}</p>`:grads.length?grads.map(g=>`<div class="item"><span class="belticon">🥋</span><div class="grow"><b>${esc(g.belt)} • ${esc(g.degree)}</b><small>${esc(g.awarded_at)}</small></div></div>`).join(''):'<p class="muted">Ainda não há graduações registradas.</p>'}</section>`;
  } else {content='<section class="panel">Tela indisponível para este perfil.</section>'}
  shell(content);
  if(page==='attendance'){
    document.querySelector('#checkin')?.addEventListener('click',async()=>{
      const result=document.querySelector('#result');result.textContent='Registrando...';
      const {error}=await supabase.from('attendance').insert({student_id:currentUser.id,method:'manual'});
      result.textContent=error?`Não foi possível registrar: ${error.message}`:'Check-in registrado com sucesso!';
      if(!error) loadAttendance();
    });
    loadAttendance();
  }
}
async function loadAttendance(){
  const {data=[],error}=await supabase.from('attendance').select('checked_in_at,method').order('checked_in_at',{ascending:false}).limit(20);
  const target=document.querySelector('#attlist');if(!target)return;
  target.innerHTML=error?esc(error.message):data.length?data.map(a=>`<div class="item"><div class="grow"><b>${new Date(a.checked_in_at).toLocaleString('pt-BR')}</b><small>Método: ${esc(a.method)}</small></div><span class="status paid">Registrada</span></div>`).join(''):'Nenhuma presença registrada ainda.';
}
if(supabase){
  supabase.auth.getSession().then(async({data})=>{if(data.session)await loadUser(data.session.user);else renderAuth()});
  supabase.auth.onAuthStateChange((_event,session)=>{if(!session){currentUser=null;profile=null;renderAuth()}});
}else renderAuth();
