-- Esquema inicial da CT Genilson Cachorrão.
-- Revise e aplique no SQL Editor do seu próprio projeto Supabase.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'student' check (role in ('teacher','student')),
  belt text not null default 'Branca',
  degree text not null default '0 grau',
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  checked_in_at timestamptz not null default now(),
  method text not null default 'manual' check (method in ('manual','qr')),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(10,2) not null check (amount >= 0),
  due_date date not null,
  paid_at timestamptz,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.graduations (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  belt text not null,
  degree text not null default '0 grau',
  awarded_at date not null default current_date,
  note text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create or replace function public.is_teacher()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'teacher'
  );
$$;

alter table public.profiles enable row level security;
alter table public.attendance enable row level security;
alter table public.memberships enable row level security;
alter table public.graduations enable row level security;

-- Perfil: cada aluno vê o próprio perfil; professor vê todos.
create policy "profiles_select_self_or_teacher" on public.profiles
for select to authenticated
using (id = auth.uid() or public.is_teacher());

create policy "profiles_update_self_or_teacher" on public.profiles
for update to authenticated
using (id = auth.uid() or public.is_teacher())
with check (id = auth.uid() or public.is_teacher());

create policy "profiles_teacher_insert" on public.profiles
for insert to authenticated
with check (public.is_teacher() or id = auth.uid());

-- Aluno vê suas presenças; professor vê todas. Aluno pode registrar apenas para si.
create policy "attendance_select_self_or_teacher" on public.attendance
for select to authenticated
using (student_id = auth.uid() or public.is_teacher());

create policy "attendance_insert_self_or_teacher" on public.attendance
for insert to authenticated
with check (student_id = auth.uid() or public.is_teacher());

create policy "attendance_delete_teacher" on public.attendance
for delete to authenticated
using (public.is_teacher());

create policy "memberships_select_self_or_teacher" on public.memberships
for select to authenticated
using (student_id = auth.uid() or public.is_teacher());

create policy "memberships_teacher_insert" on public.memberships
for insert to authenticated
with check (public.is_teacher());

create policy "memberships_teacher_update" on public.memberships
for update to authenticated
using (public.is_teacher())
with check (public.is_teacher());

create policy "memberships_teacher_delete" on public.memberships
for delete to authenticated
using (public.is_teacher());

create policy "graduations_select_self_or_teacher" on public.graduations
for select to authenticated
using (student_id = auth.uid() or public.is_teacher());

create policy "graduations_teacher_insert" on public.graduations
for insert to authenticated
with check (public.is_teacher());

create policy "graduations_teacher_update" on public.graduations
for update to authenticated
using (public.is_teacher())
with check (public.is_teacher());

create policy "graduations_teacher_delete" on public.graduations
for delete to authenticated
using (public.is_teacher());

-- IMPORTANTE:
-- Crie o primeiro usuário no Authentication e depois atribua role='teacher'
-- ao respectivo id manualmente no painel do Supabase.
-- Não permita que usuários escolham sua própria role de professor.
