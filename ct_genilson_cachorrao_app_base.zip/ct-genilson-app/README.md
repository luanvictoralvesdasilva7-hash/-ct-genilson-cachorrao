# CT Genilson Cachorrão — base do aplicativo

Este pacote contém uma base inicial de aplicativo web responsivo com tema preto, vermelho e branco, autenticação via Supabase, áreas por perfil e tabelas para perfis, presenças, mensalidades e graduações.

## Importante
- O projeto ainda precisa ser configurado no seu próprio Supabase e hospedado para ficar online.
- Não é um app publicado na App Store/Google Play.
- Não coloque dados reais de alunos até revisar e testar permissões.
- O primeiro usuário professor deve ser promovido manualmente no painel, depois de criar sua conta.
- Não compartilhe a chave `service_role`. No frontend use apenas a chave pública anon/publishable.

## Arquivos
- `src/main.js`: telas e lógica inicial.
- `src/style.css`: tema responsivo.
- `supabase/schema.sql`: tabelas e políticas RLS iniciais.
- `.env.example`: variáveis necessárias.

## Configuração técnica (para executar em computador)
1. Instale Node.js LTS.
2. Descompacte o pacote e execute `npm install`.
3. Crie um projeto no Supabase.
4. Abra SQL Editor no Supabase e execute `supabase/schema.sql`.
5. Copie `.env.example` para `.env.local` e preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
6. Crie usuários em Authentication e seus perfis correspondentes em `profiles`. Para a primeira conta, atribua `role = 'teacher'` no painel do banco.
7. Execute `npm run dev` para testar localmente e `npm run build` para compilar.
8. Hospede em um serviço de hospedagem estática e configure as mesmas variáveis de ambiente.

## Limitações desta primeira base
- Cadastro/invite de usuários ainda não está implementado como fluxo administrativo completo.
- Não existe QR Code real; o check-in atual é manual.
- Não há integração com cobrança ou pagamentos.
- Antes de produção, é necessária revisão de segurança, teste das políticas RLS e validação de todas as permissões.
